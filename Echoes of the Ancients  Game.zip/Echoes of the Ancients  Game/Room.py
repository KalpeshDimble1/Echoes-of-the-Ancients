class Room:
    def __init__(self, description):
        self.description = description
        self.exits = {}  
        self.quest = None 
        self.herbs = False  
        self.enemy = None 
        self.treasure = None  
        self.requires_key = False  

    #Def all the methods here
    
    def set_exit(self, direction, neighbour):
        self.exits[direction] = neighbour

    def set_quest(self, quest_description, reward, exp_gain):
        self.quest = {"description": quest_description, "reward": reward, "exp_gain": exp_gain}

    def set_herbs(self, available):
        self.herbs = available

    def set_enemy(self, enemy_name, damage, exp_gain, health):
        self.enemy = {"name": enemy_name, "damage": damage, "exp_gain": exp_gain, "health": health}

    def set_treasure(self, treasure_name, requires_key=False):
        self.treasure = treasure_name
        self.requires_key = requires_key

    def get_exits(self):
        return list(self.exits.keys())

    def get_exit(self, direction):
        return self.exits.get(direction)

    def collect_herbs(self):
        if self.herbs:
            self.herbs = False
            return True
        return False
    
    def set_treasure(self, treasure_name, requires_key=False):
      
        self.treasure = treasure_name
        self.requires_key = requires_key

    #It ensure the player has the key before they can take the treasure
    def collect_treasure(self, has_key=False):
       
        if not self.treasure:
            print("No treasure to collect here.")
            return None
    
        if self.requires_key and not has_key:
            print("You cannot collect the treasure. Please collect the key from the Ancient Ruins first.")
            return None
        
        # Treasure is collected
        collected_treasure = self.treasure
        self.treasure = None  
        print(f"You collected: {collected_treasure}!")
        return collected_treasure

        #Regenrate the Enemy,Quest and Herbs
    def reset_room(self):
        if self.enemy:
            self.enemy["health"] = 50  
        if self.treasure:
            self.treasure = "Gem"  
        if self.herbs:
            self.herbs = True    