class TextUI:
    def show_help(self):
        print("\nCommands:")
        print("  go [location name] - Move to a different room.")
        print("  inventory - Check your inventory.")
        print("  collect - Collect herbs if available.")
        print("  treasure - Collect treasure in the current room.")
        print("  stats - Check your current stats.")
        print("  quit - Exit the game.")
        print("  fight - Engage in combat with an enemy.")

    def show_stats(self, player):
        print("\nPlayer Stats:")
        print(f"  Name: {player.name}")
        print(f"  Stamina: {player.stamina}")
        print(f"  Level: {player.level}")
        print(f"  Experience: {player.experience}")


    def get_long_description(self, room):
       #Creating Description 
        exits_text = ', '.join(room.get_exits())
        quest_text = f"Quest: {room.quest['description']}" if room.quest else "Quest: No quests here."
        herb_text = "Herbs: You see herbs you can collect." if room.herbs else "Herbs: No herbs to collect here."
        enemy_text = f"Enemies: {room.enemy['name']} is here with {room.enemy['health']} HP!" if room.enemy else "Enemies: No enemies nearby."
        treasure_text = (f"Treasures: You see a treasure: {room.treasure}."if room.treasure and not room.requires_key else "Treasures: A treasure is here, but it seems locked. First Collect the key from Ancient Ruins"
                         if room.treasure else "Treasures: No treasure to collect here.")
        return f"Location: {room.description}\nGo: {exits_text}\n{quest_text}\n{herb_text}\n{enemy_text}\n{treasure_text}"
