class Backpack:
    def collect_herbs(self, current_room):
        if current_room.herbs:
            current_room.herbs = False
            print("You collected herbs!")
        else:
            print("No herbs to collect here.")

    def collect_treasure(self, current_room):
        if current_room.treasure:
            treasure = current_room.treasure
            current_room.treasure = None
            print(f"You found a treasure: {treasure}!")
        else:
            print("No treasure to collect here.")

    def add_item(self, inventory, name, description):
        inventory[name] = description
        print(f"You have acquired: {name}")

    def restore_stamina(self, stamina, amount):
        return min(stamina + amount, 100)

    def show_inventory(self, inventory):
        if inventory:
            print("\nInventory:")
            for item, desc in inventory.items():
                print(f"  {item}: {desc}")
        else:
            print("Your inventory is empty.")
