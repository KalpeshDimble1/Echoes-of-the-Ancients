from Room import Room
from Backpack import Backpack
from TextUI import TextUI

class Game:
    def __init__(self):
        self.rooms = {}
        self.herbs_collected = []
        self.create_world()
        self.player = None
        self.text_ui = TextUI()
        self.backpack = Backpack()
        self.current_room = None
        self.key_collected = False

        #Create rooms and add them to the dictionary
    def create_world(self):
        self.rooms["Forest"] = Room("You are in a dense forest. Herbs grow here.")
        self.rooms["Village"] = Room("You are in a peaceful village. You can rest here.")
        self.rooms["Mountain"] = Room("You stand at the base of a towering mountain.")
        self.rooms["Cave"] = Room("You enter a dark cave. It smells of danger.")
        self.rooms["Mystic Lake"] = Room("You arrive at a tranquil Mystic Lake. It glows with magical energy.")
        self.rooms["Sky Fortress"] = Room("You ascend to the Sky Fortress. It's guarded by ancient beings.")
        self.rooms["Ancient Ruins"] = Room("You are in the Ancient Ruins. A mystical key lies hidden here.")
        self.rooms["Farm"] = Room("You are in the Farm. You can collect protein here for survival.")

        #Set herbs in Rooms
        self.rooms["Forest"].set_herbs(True)  
        self.rooms["Mountain"].set_herbs(True)

    
        # Exits door for the Forest
        self.rooms["Forest"].set_exit("to the Village", self.rooms["Village"])
        self.rooms["Forest"].set_exit("to the Cave", self.rooms["Cave"])
        self.rooms["Forest"].set_exit("to the Mountain", self.rooms["Mountain"])
        self.rooms["Forest"].set_exit("to the Ancient Ruins", self.rooms["Ancient Ruins"])

        # Exits door for the Village
        self.rooms["Village"].set_exit("to the Forest", self.rooms["Forest"])
        self.rooms["Village"].set_exit("to the Cave", self.rooms["Cave"])
        self.rooms["Village"].set_exit("to the Mountain", self.rooms["Mountain"])
        self.rooms["Village"].set_exit("to the Ancient Ruins", self.rooms["Ancient Ruins"])
        self.rooms["Village"].set_exit("to the Farm", self.rooms["Farm"])

        # Exits door for the Mountain
        self.rooms["Mountain"].set_exit("to the Forest", self.rooms["Forest"])
        self.rooms["Mountain"].set_exit("to the Cave", self.rooms["Cave"])
        self.rooms["Mountain"].set_exit("to the Village", self.rooms["Village"])
        self.rooms["Mountain"].set_exit("to the Mystic Lake", self.rooms["Mystic Lake"])
        self.rooms["Mountain"].set_exit("to the Ancient Ruins", self.rooms["Ancient Ruins"])

        # Exits door for the Mystic Lake
        self.rooms["Mystic Lake"].set_exit("to the Mountain", self.rooms["Mountain"])
        self.rooms["Mystic Lake"].set_exit("to the Sky Fortress", self.rooms["Sky Fortress"])

        # Exits door for the Sky Fortress
        self.rooms["Sky Fortress"].set_exit("down", self.rooms["Mystic Lake"])
        self.rooms["Sky Fortress"].set_exit("to the Mountain", self.rooms["Mountain"])

         # Exits door for the Farm
        self.rooms["Farm"].set_exit("to the Village", self.rooms["Village"])

        # Exits for the Cave
        self.rooms["Cave"].set_exit("to the Forest", self.rooms["Forest"])
        self.rooms["Cave"].set_exit("to the Village", self.rooms["Village"])
        self.rooms["Cave"].set_exit("to the Mountain", self.rooms["Mountain"])
        self.rooms["Cave"].set_exit("to the Ancient Ruins", self.rooms["Ancient Ruins"])

        # Exits for the Ancient Ruins
        self.rooms["Ancient Ruins"].set_exit("to the Forest", self.rooms["Forest"])
        self.rooms["Ancient Ruins"].set_exit("to the Village", self.rooms["Village"])
        self.rooms["Ancient Ruins"].set_exit("to the Mountain", self.rooms["Mountain"])
        self.rooms["Ancient Ruins"].set_exit("to the Cave", self.rooms["Cave"])
    
        # Code For Creating Enemey
        self.rooms["Cave"].set_enemy("Dangerous Animal", damage=30, exp_gain=50, health=100)
        self.rooms["Sky Fortress"].set_enemy("Sky Guardian", damage=50, exp_gain=150, health=200)

        #Create Treasure
        self.rooms["Ancient Ruins"].set_treasure("Key")  # Key in Ancient Ruins
        self.rooms["Cave"].set_treasure("Gem", requires_key=True)  # Gem in the Cave

        # Create Quest
        self.rooms["Mountain"].set_quest(
            quest_description="Find a mystical artifact hidden on the summit.",
            reward="Mystical Artifact",
            exp_gain=50,
        )

        self.rooms["Mystic Lake"].set_quest(
            quest_description="Find the mystical power hidden in the lake.",
            reward="Mystic Power",
            exp_gain=100,
        )

        self.rooms["Sky Fortress"].set_quest(
            quest_description="Defeat the Sky Guardian.",
            reward="Sky Key",
            exp_gain=150,
        )

        self.rooms["Farm"].set_quest(
            quest_description="Collect Food for survival.",
            reward="Food",
            exp_gain=20,
        )


    #collecting herbs
    def collect_herbs(self):
        if self.current_room.collect_herbs():
            self.herbs_collected.append("Herb")
            #Restore the player's health
            self.player.restore_stamina(20) 
            print("You collected herbs and restored stamina!")
        else:
            print("No herbs to collect here.")


    # Collecting treasure
    def collect_treasure(self):
        """
        Handle treasure collection in the current room.
        """
        treasure = self.current_room.collect_treasure(has_key=self.key_collected)
        if treasure:
            if treasure == "Key":
                self.key_collected = True
                print("You collected the key!")
            elif treasure == "Gem":
                print("You collected the gem!")
            else:
                print(f"You collected: {treasure}!")
        else:
            print("You cannot collect the treasure without the required key.")

    
    #key Collection
    def collect_key(self):
        """
        Collect the key if available in the current room.
        """
        if self.current_room.treasure == "Key":
            self.key_collected = True
            self.current_room.treasure = None
            print("You collected the key!")
        else:
            print("No key to collect here.")

    #Gem Collection
    def collect_gem(self):
        """
        Attempt to collect the gem.
        """
        if self.key_collected:
            treasure = self.current_room.collect_treasure(has_key=True)
            if treasure == "Gem":
                print("You collected the gem!")
            elif treasure:
                print(f"You collected: {treasure}")
        else:
            print("You need a key to collect the gem!")

    
 
    def fight_enemy(self):
        
        #Fight with an enemy in the current room.
        
        if not self.current_room.enemy:
            print("No enemies to fight here.")
            return
        enemy = self.current_room.enemy
        print(f"Fighting {enemy['name']}!")
        print(f"Enemy Health: {enemy['health']} HP")

        while True:
            # Player attacks on enemy
            player_damage = 40  
            enemy["health"] -= player_damage
            print(f"You attack the {enemy['name']} and deal {player_damage} damage.")
            if enemy["health"] <= 0:
                print(f"You defeated the {enemy['name']}!")
                print(f"You gained {enemy['exp_gain']} XP!")
                self.player.gain_experience(enemy["exp_gain"])
                self.current_room.enemy = None  # Enemy defeated
                return
            print(f"Enemy Health: {enemy['health']} HP")

            # Enemy attacks on player
            enemy_damage = enemy["damage"]
            self.player.stamina -= enemy_damage
            print(f"The {enemy['name']} attacks you and deals {enemy_damage} damage.")
            if self.player.stamina <= 0:
                print(f"You were defeated by the {enemy['name']}! Game Over.")
                self.restart_game()
                return
            print(f"Your Stamina: {self.player.stamina} HP")

    def handle_quest(self):
        
        #Handle the quest to ensure quest is complete or not in room.
      
        if self.current_room.quest:
            quest = self.current_room.quest
            print(f"Quest Available: {quest['description']}")
            choice = input("Do you want to complete this quest? (yes/no): ").lower()
            if choice == "yes":
                print(f"You completed the quest: {quest['description']}")
                print(f"Reward: {quest['reward']} and {quest['exp_gain']} XP!")
                self.player.gain_experience(quest['exp_gain'])
                self.backpack.add_item(self.player.inventory, quest['reward'], f"Found in {self.current_room.description}")
                self.current_room.quest = None  
                exits_text = ', '.join(self.current_room.get_exits())
                print(f"Next, you can go: {exits_text}.")
            else:
                print("You chose not to complete the quest.")
                exits_text = ', '.join(self.current_room.get_exits())
                print(f"Next, you can go: {exits_text}.") 
        else:
            print("No quests available in this room.")
            
    def restart_game(self):
        
        #If I lost from Enemy the game will restart.

        print("Restarting game...")
        self.player.stamina = 100
        self.current_room = self.rooms["Forest"]
        print("You are back at the Forest with full stamina.")

    def play(self):
        print("Welcome to the Echoes of the Ancients!")
        player_name = input("Enter your player's name: ")
        self.player = Player(player_name, 100)
        self.current_room = self.rooms["Forest"]

        while True:
            print(f"\n{self.text_ui.get_long_description(self.current_room)}")
            command = input("\nEnter your command: ").lower().split()
            if not command:
                print("Invalid command.")
                continue

            action = command[0]
            if action == "help":
                self.text_ui.show_help()
            elif action == "stats":
                self.text_ui.show_stats(self.player)
            elif action == "collect":
                self.backpack.collect_herbs(self.current_room)
            elif action == "treasure":
                self.backpack.collect_treasure(self.current_room)
            elif action == "quest":
                self.handle_quest()  
            elif action == "fight":
                self.fight_enemy()  
            elif action == "go":
                if len(command) > 1:
                    self.move(" ".join(command[1:]))
                else:
                    print("Go where?")
            elif action == "quit":
                print("Thank you for playing! Goodbye.")
                break
            else:
                print("Unknown command. Type 'help' for options.")

    def move(self, location_name):
        
        #Move to a room given location name.
        
        for exit_name, next_room in self.current_room.exits.items():
            if location_name.lower() in exit_name.lower():  
                self.current_room = next_room
                print(f"You moved to {self.current_room.description}.")
                return
        print(f"You can't go that way. There's no exit named '{location_name}'.")

class Player:
    def __init__(self, name, stamina):
        self.name = name
        self.stamina = stamina
        self.level = 1
        self.experience = 0
        self.inventory = {}
        self.key_collected = False 
        self.current_room = None
        self.herbs_collected = []
        self.player = Player

    def gain_experience(self, amount):
        self.experience += amount
        if self.experience >= 100 * self.level:
            self.level += 1
            print(f"Congratulations! You leveled up to Level {self.level}!")

if __name__ == "__main__":
    game = Game()
    game.play()